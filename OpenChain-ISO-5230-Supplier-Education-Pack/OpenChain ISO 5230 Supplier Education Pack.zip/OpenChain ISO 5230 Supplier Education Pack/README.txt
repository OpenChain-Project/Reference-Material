Welcome to the OpenChain ISO 5230 Supplier Education Pack!

This pack contains four files that you can (a) read in order or (b) skip to the content that is not familiar to you.

If you know open source, but you are new to OpenChain, please start with 'basic-overview-of-openchain-iso5230'

basic-open-source-education
basic-overview-of-openchain-iso5230
how-openchain-iso5230-works
reference-staff-training-slides

Our goal is to help your organization become OpenChain ISO 5230 conformant. We are here to help with each step of the process. You can speak to us in confidence and without any cost or conditions.

Contact us at: info@openchainproject.org

The project website and our large international community can be found here:
https://www.openchainproject.org/